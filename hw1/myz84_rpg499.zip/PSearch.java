import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * PSearch searches an int array for an int value, returning the index of the first instance of the value if it is found or -1 if
 * it is not found. PSearch will create multiple threads to evenly spread the sequential searching based on specified number of processors
 * available.
 *
 * Created by Matt on 2/2/2015.
 * Authors: Matthew Zhan, Robert Golshan
 * myz84, rpg499
 */

public class PSearch {


    static int numThreads = Runtime.getRuntime().availableProcessors();     //numThreads value, default set to the number that the system has available
    //static int numThreads = 2;
    static final ExecutorService executor = Executors.newFixedThreadPool(numThreads);
    public static ArrayList<Future<Integer>> indices = new ArrayList<Future<Integer>>();


    public static void main(String args[]) throws Exception {
        int[] arr = new int[20];                        //int array to be searched
        for(int i = 0; i < arr.length; i++) {
            arr[i] = (int)(Math.random()*10);
        }
        //arr = new int[]{4,3,2,1,0};
        System.out.println("Original Array:\t"+Arrays.toString(arr));
        int x = (int)(Math.random()*10);                //int value to be found
        int index = parallelSearch(x, arr, numThreads); //index if x is found in the array
        System.out.println("indexOf "+x+": "+index);
        executor.shutdown();
    }

    /**
     * parallelSearch
     * searches an array A for value x, if x is found, then the index of the first instance of x is returned
     * uses multiple threads to sequentially search through parts of the array
     * @param x
     * @param A
     * @param numThreads
     * @return index or -1 if not found
     * @throws Exception
     */
    public static int parallelSearch(int x, int[] A, int numThreads) throws Exception {
        int quo = A.length/numThreads;              // quotient of length/numThreads, used for determining the length each thread will search through

        for(int i=0; i < numThreads-1;i++) {        // if there is more than one thread available, then create a new callable object that will do a sequential search for numThreads-1, each of size quotient
            Search search = new Search(x, A, i * quo, ((i + 1) * quo) - 1);
            Future<Integer> future = executor.submit(search);
            indices.add(future);                    //add the future object to a list of all the future objects created to later get the indices
        }
        Search search = new Search(x, A, quo * (numThreads-1), A.length - 1);   //in the case that the length of the array cannot be split evenly, the remainder is given this last thread.
        Future<Integer> future = executor.submit(search);                       //if only one thread is available then the above for loop is skipped for this single callable object
        indices.add(future);                        //add the future object to a list of all the future objects created to later get the indices

        for(Future<Integer> fut : indices) {
            try{
                if(fut.get()!=-1)
                    return fut.get();               //check all future objects to see if x is found in any of the sub array searches

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return -1;
    }


    /**
     * callable search object that does a sequential search on an array from a start and end point
     */
    static class Search implements Callable<Integer> {

        int[] my_array;
        int x;
        int begin, end;


        public Search(int x, int[] A, int begin, int end) {
            this.x = x;
            this.my_array = A;
            this.begin = begin;
            this.end = end;
        }

        @Override
        /**
         * call function is a sequential search through part of an array
         */
        public Integer call() throws Exception {
            for(int i = begin; i <= end; i++) {
                if(my_array[i]==x)
                    return i;
            }
            return -1;
        }

    }

}

