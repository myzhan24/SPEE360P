import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.*;

/**
 * PSort is a parallel quick sort on an array of integers for ascending order
 *
 * Created by Matt on 2/2/2015.
 * Authors: Matthew Zhan, Robert Golshan
 * myz84 rpg499
 */

public class PSort implements Runnable{

    static int numThreads = Runtime.getRuntime().availableProcessors();     //numThreads value, default set to the number that the system has available
    //static int numThreads = 2;
    static final ExecutorService executor = Executors.newFixedThreadPool(numThreads);
    public static ArrayList<Future<?>> futures = new ArrayList<Future<?>>();

    final int[] my_array;
    final int begin, end;
    static boolean doneSorting = false;                     //finished condition

    public PSort(int[] A,int b, int e) {
        my_array = A;
        begin = b;
        end = e;
    }

    public static void main(String args[]) throws Exception {
        int[] arr = new int[30];                        //int array to be searched
        for(int i = 0; i < arr.length; i++) {
            arr[i] = (int)(Math.random()*100);
        }
        //arr = new int[]{4,3,2,1,0};
        PSort p1 = new PSort(arr,0,arr.length-1);
        System.out.println("Original Array:\t"+Arrays.toString(p1.my_array));
        p1.run();   //start the parallel sort

        //executor.awaitTermination(2,TimeUnit.SECONDS);

        while(!doneSorting){        //checks if any future tasks still need to be run, once they are all finished, the array is sorted
            try {
                doneSorting = true;
                for(Future f : futures)
                {
                    if(!f.isDone()) {
                        doneSorting = false;
                        break;
                    }
                }
            } catch (Exception e){
                //System.out.println("concurrent error, trying again");
                doneSorting = false;
            }
        }

        executor.shutdown();
        System.out.print("Sorted Array:\t");
        System.out.println(Arrays.toString(p1.my_array));
    }

    /**
     * parallelSort
     * sorts an int array by recursively creating two new threads to sort each subarray created by each pivot placement
     * @param A     array
     * @param begin begin index to sort
     * @param end   end index to sort
     */
    public static void parallelSort(int[] A, int begin, int end) {
        int length = end - begin + 1;           //the number of elements of the subarray to search
        if(length <= 1)
            return;                             // no more elements to search if the length is 1 or less

        int pivotIndex = median(A, begin, end); //Pick a pivot from the array, using the median of the start middle and end
        int pivotValue = A[pivotIndex];

        //System.out.println(Arrays.toString(A)+" pivot: "+pivotValue+" for partition ["+begin+","+end+"]");

        swap(A, pivotIndex, end);               //put chosen pivot at the end of the array

        int storeIndex = begin;                 //index for swapping elements lower than the pivot value
        for(int i = begin; i < end; i++) {
            if(A[i] <= pivotValue){
                swap(A, i, storeIndex);         //for each element of the subarray, if the value is lower than the pivot, then move it into the index of storeindex
                storeIndex++;
            }
        }

        swap(A, storeIndex, end);               //swap the pivot value and the storeIndex to place the pivot in the correct spot


        PSort psort = new PSort(A, begin,storeIndex-1);     //create two new threads to sort the subarrays
        futures.add(executor.submit(psort));                //all values below the pivot still need to be sorted
        psort = new PSort(A, storeIndex+1,end);             //all values above the pivot still need to be sorted
        futures.add(executor.submit(psort));
    }

    @Override
    public void run() {
        parallelSort(my_array, begin, end);
        //System.out.println("thread done for ["+begin+","+end+"]");
    }

    /**
     * returns the index of the median value of the first, middle, and last element of an array
     * used for picking the pivot
     * @param A
     * @param begin
     * @param end
     * @return
     */
    public static int median(int[] A, int begin, int end) {
        int middle = (end - begin)/2;
        int a = A[begin];
        int b = A[end];
        int c = A[middle];

        // a is the median
        if((a >= c && a <= b)||(a >= b && a <= c))
        {
            return begin;
        }
        // b is the median
        else if((b >= c && b <= a)||(b >= a && b <= c))
        {
            return end;
        }
        //c is the median: A <= C <= B or B <= C <= A
        else if((c >= a && c <= b)||(c >= b && c <= a))
        {
            return middle;
        }
        else{
            System.out.println("Median ERROR");
            return begin;
        }

    }

    /**
     * swap
     * swaps two values in an array using index i and index j
     * @param A
     * @param i
     * @param j
     */
    public static void swap(int[] A, int i, int j) {
        int temp = A[i];
        A[i] = A[j];
        A[j] = temp;
    }
}